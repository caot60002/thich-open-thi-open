-- Database Schema for User Presence API
-- Chạy script này trong phpMyAdmin hoặc cPanel → phpMyAdmin

-- Tạo database (nếu chưa có)
-- CREATE DATABASE user_presence_db;
-- USE user_presence_db;

-- Bảng user_presence
CREATE TABLE IF NOT EXISTS user_presence (
  uid VARCHAR(255) PRIMARY KEY,
  source VARCHAR(100),
  status ENUM('online', 'offline') NOT NULL,
  last_ping BIGINT NOT NULL,
  last_ping_iso VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_last_ping (last_ping)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Xóa dữ liệu cũ (optional)
-- DELETE FROM user_presence WHERE last_ping < UNIX_TIMESTAMP() * 1000 - 25000;

-- Xem dữ liệu
-- SELECT * FROM user_presence ORDER BY last_ping DESC;
