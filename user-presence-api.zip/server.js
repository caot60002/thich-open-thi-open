const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3000;

// Database connection pool
let pool;

// Initialize database connection
async function initDatabase() {
  try {
    console.log('========================================');
    console.log('Starting User Presence API...');
    console.log('========================================');
    console.log('Database Configuration:');
    console.log(`  Host: ${process.env.DB_HOST || 'localhost'}`);
    console.log(`  User: ${process.env.DB_USER || 'NOT SET'}`);
    console.log(`  Database: ${process.env.DB_NAME || 'NOT SET'}`);
    console.log(`  Port: ${PORT}`);
    console.log('========================================');

    // Check required environment variables
    if (!process.env.DB_USER || !process.env.DB_PASSWORD || !process.env.DB_NAME) {
      throw new Error('Missing required database credentials. Please set DB_USER, DB_PASSWORD, and DB_NAME environment variables.');
    }

    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 0,
      connectTimeout: 10000, // 10 seconds timeout
      acquireTimeout: 10000
    });

    // Test connection
    console.log('Attempting to connect to database...');
    const connection = await pool.getConnection();
    console.log('✓ Database connected successfully');
    connection.release();

    // Create table if not exists
    await createTable();
  } catch (error) {
    console.error('✗ Database connection failed!');
    console.error('Error:', error.message);
    console.error('Code:', error.code || 'UNKNOWN');
    console.error('');
    console.error('SERVER WILL START BUT DATABASE API WILL NOT WORK!');
    console.error('Please check:');
    console.error('  1. Database exists in phpMyAdmin');
    console.error('  2. DB_USER, DB_PASSWORD, DB_NAME are correct');
    console.error('  3. User has proper permissions');
    console.error('========================================');
    // Don't throw error - let server start anyway
    pool = null;
  }
}

// Create table
async function createTable() {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS user_presence (
      uid VARCHAR(255) PRIMARY KEY,
      source VARCHAR(100),
      status ENUM('online', 'offline') NOT NULL,
      last_ping BIGINT NOT NULL,
      last_ping_iso VARCHAR(50),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_status (status),
      INDEX idx_last_ping (last_ping)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `;

  try {
    await pool.execute(createTableQuery);
    console.log('Table "user_presence" ready');
  } catch (error) {
    console.error('Error creating table:', error.message);
    throw error;
  }
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Enable CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// API: /api/ping - Update user status
app.all('/api/ping', async (req, res) => {
  const { uid, source, status } = req.method === 'GET' ? req.query : (req.body || {});

  // Validation: Check uid
  if (!uid) {
    return res.status(400).json({
      error: 'Missing uid parameter',
      usage: 'Example: /api/ping?uid=123&source=executor&status=online'
    });
  }

  // Validation: Check status
  if (!status || (status !== 'online' && status !== 'offline')) {
    return res.status(400).json({
      error: 'Invalid or missing status parameter',
      usage: 'status must be either "online" or "offline"'
    });
  }

  // Check if database is connected
  if (!pool) {
    return res.status(503).json({
      error: 'Database not connected',
      message: 'Server is running but database connection failed. Please check server logs.'
    });
  }

  try {
    const now = Date.now();
    const nowISO = new Date(now).toISOString();

    // UPSERT - Update if exists, insert if new
    const query = `
      INSERT INTO user_presence (uid, source, status, last_ping, last_ping_iso)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        source = VALUES(source),
        status = VALUES(status),
        last_ping = VALUES(last_ping),
        last_ping_iso = VALUES(last_ping_iso),
        updated_at = CURRENT_TIMESTAMP
    `;

    await pool.execute(query, [uid, source || 'unknown', status, now, nowISO]);

    // Log for debugging
    console.log(`[${new Date().toISOString()}] UID: ${uid} | Status: ${status} | Source: ${source || 'unknown'}`);

    // Return success response
    return res.status(200).json({
      success: true,
      message: `Status updated to ${status}`,
      data: {
        uid: uid,
        source: source || 'unknown',
        status: status,
        lastPing: now,
        lastPingISO: nowISO
      }
    });

  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
});

// API: /api/status/:uid - Get user status
app.get('/api/status/:uid', async (req, res) => {
  const { uid } = req.params;

  // Validation
  if (!uid) {
    return res.status(400).json({ error: 'Missing uid parameter' });
  }

  // Check if database is connected
  if (!pool) {
    return res.status(503).send('offline');
  }

  try {
    // Check if user exists and was last pinged within 25 seconds
    const twentyFiveSecondsAgo = Date.now() - 25000;

    const query = `
      SELECT status, last_ping, last_ping_iso
      FROM user_presence
      WHERE uid = ? AND last_ping > ?
      LIMIT 1
    `;

    const [rows] = await pool.execute(query, [uid, twentyFiveSecondsAgo]);

    // If no recent data found, user is offline
    if (!rows || rows.length === 0) {
      console.log(`[${new Date().toISOString()}] UID: ${uid} | Status: offline (not found or expired)`);
      return res.status(404).send('offline');
    }

    const user = rows[0];

    // Log for debugging
    console.log(`[${new Date().toISOString()}] UID: ${uid} | Status: ${user.status}`);

    // Return plain text status
    return res.status(200).send(user.status);

  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
});

// API: /api/stats - Get statistics (optional)
app.get('/api/stats', async (req, res) => {
  if (!pool) {
    return res.status(503).json({
      error: 'Database not connected',
      message: 'Server is running but database connection failed.'
    });
  }

  try {
    const twentyFiveSecondsAgo = Date.now() - 25000;

    const [onlineRows] = await pool.execute(
      'SELECT COUNT(*) as count FROM user_presence WHERE status = ? AND last_ping > ?',
      ['online', twentyFiveSecondsAgo]
    );

    const [totalRows] = await pool.execute(
      'SELECT COUNT(*) as count FROM user_presence WHERE last_ping > ?',
      [twentyFiveSecondsAgo]
    );

    return res.status(200).json({
      online: onlineRows[0].count,
      total: totalRows[0].count,
      offline: totalRows[0].count - onlineRows[0].count,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
});

// Health check endpoint
app.get('/health', async (req, res) => {
  if (!pool) {
    return res.status(503).json({
      status: 'error',
      database: 'disconnected',
      message: 'Database connection failed. Check server logs for details.',
      timestamp: new Date().toISOString()
    });
  }

  try {
    // Check database connection
    await pool.query('SELECT 1');

    res.status(200).json({
      status: 'ok',
      database: 'connected',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      database: 'disconnected',
      error: error.message
    });
  }
});

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();

    app.listen(PORT, '0.0.0.0', () => {
      console.log('');
      console.log('========================================');
      console.log('✓ Server is running!');
      console.log(`  Port: ${PORT}`);
      console.log(`  Environment: ${process.env.NODE_ENV || 'production'}`);
      console.log('========================================');
      console.log('API endpoints:');
      console.log(`  POST/GET /api/ping - Update user status`);
      console.log(`  GET /api/status/:uid - Get user status`);
      console.log(`  GET /api/stats - Get statistics`);
      console.log(`  GET /health - Health check`);
      console.log('========================================');
      console.log('');
    });
  } catch (error) {
    console.error('Failed to start server:', error.message);
    console.error('Error details:', JSON.stringify(error, null, 2));
    process.exit(1);
  }
}

startServer();
