# Hướng dẫn cài đặt trên cPanel (Phiên bản MySQL)

## Yêu cầu hệ thống
- Node.js >= 18.0.0
- cPanel với hỗ trợ Node.js
- MySQL/MariaDB database

## Bước 1: Tạo Database trong cPanel

1. Đăng nhập vào cPanel
2. Tìm phần **"Databases"** → **"MySQL Database Wizard"**
3. Tạo database:
   - **New Database**: Nhập tên database (ví dụ: `user_presence_db`)
   - Click **"Create Database"**
4. Tạo database user:
   - **Username**: Nhập username
   - **Password**: Tạo password mạnh
   - Click **"Create User"**
5. Add user to database:
   - Chọn **"ALL PRIVILEGES"**
   - Click **"Make Changes"**

Lưu lại thông tin:
- Database name: `username_user_presence_db`
- Database user: `username_dbuser`
- Database password: `(password của bạn)`
- Host: Thường là `localhost`

## Bước 2: Tạo Bảng Dữ Liệu

1. Trong cPanel, tìm **"Databases"** → **"phpMyAdmin"**
2. Chọn database bạn vừa tạo
3. Click tab **"SQL"**
4. Copy và paste nội dung file `database.sql` vào
5. Click **"Go"** để thực thi

Hoặc chạy trực tiếp trong SQL tab:
```sql
CREATE TABLE IF NOT EXISTS user_presence (
  uid VARCHAR(255) PRIMARY KEY,
  source VARCHAR(100),
  status ENUM('online', 'offline') NOT NULL,
  last_ping BIGINT NOT NULL,
  last_ping_iso VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_last_ping (last_ping)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## Bước 3: Upload Files

1. Upload tất cả file trong thư mục này lên host
2. Upload lên thư mục: `public_html/user-presence-api` (hoặc thư mục bạn muốn)

## Bước 4: Cấu hình Environment Variables

1. Đổi tên file `.env.example` thành `.env`
2. Mở file `.env` và thêm thông tin database:
   ```env
   DB_HOST=localhost
   DB_USER=username_dbuser
   DB_PASSWORD=your_password_here
   DB_NAME=username_user_presence_db
   PORT=3000
   ```
   Thay thế bằng thông tin database của bạn ở Bước 1

## Bước 5: Cài đặt Node.js App

1. Trong cPanel, tìm **"Software"** → **"Setup Node.js App"**
2. Click **"Create Application"**
3. Điền thông tin:

   | Cài đặt | Giá trị |
   |---------|---------|
   | Node.js version | 18.x (hoặc mới nhất) |
   | Application mode | Production |
   | Application root | `user-presence-api` |
   | Application URL | Chọn domain/subdomain |
   | Application startup file | `server.js` |

4. Click **"Create"**

## Bước 6: Thêm Environment Variables

1. Sau khi tạo app, click vào tên application
2. Phần **"Environment variables"**, click **"Add variable"**:
   - `DB_HOST` = `localhost`
   - `DB_USER` = `username_dbuser`
   - `DB_PASSWORD` = `your_password`
   - `DB_NAME` = `username_user_presence_db`
   - `PORT` = `3000`

3. Click **"Update"**

## Bước 7: Khởi động App

1. Trong application detail, click **"Restart"** để restart app
2. Chờ vài giây để app khởi động
3. Check log để đảm bảo không có lỗi

## Bước 8: Kiểm tra hoạt động

Truy cập các URL sau để test:

### Health Check
```
https://your-domain.com/health
```
Phải trả về: `{"status":"ok","database":"connected",...}`

### Test Ping (Update status)
```
https://your-domain.com/api/ping?uid=test123&status=online
```
Phải trả về: `{"success":true,"message":"Status updated to online",...}`

### Test Get Status
```
https://your-domain.com/api/status/test123
```
Phải trả về: `online` (nếu ping trong 25 giây trước)

### Test Statistics (optional)
```
https://your-domain.com/api/stats
```
Trả về số lượng user online/total

## API Endpoints

### 1. Update User Status
```
POST/GET /api/ping
```

**Parameters:**
- `uid` (bắt buộc): User ID
- `status` (bắt buộc): "online" hoặc "offline"
- `source` (tùy chọn): Nguồn ping (default: "unknown")

**Ví dụ:**
```bash
# GET request
GET /api/ping?uid=123&source=executor&status=online

# POST request
POST /api/ping
Content-Type: application/json

{
  "uid": "123",
  "source": "executor",
  "status": "online"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Status updated to online",
  "data": {
    "uid": "123",
    "source": "executor",
    "status": "online",
    "lastPing": 1708742345678,
    "lastPingISO": "2024-02-23T15:32:25.678Z"
  }
}
```

### 2. Get User Status
```
GET /api/status/:uid
```

**Ví dụ:**
```bash
GET /api/status/123
```

**Response:**
- `200 online` - User đang online
- `404 offline` - User offline hoặc không tìm thấy

### 3. Get Statistics (Optional)
```
GET /api/stats
```

**Response:**
```json
{
  "online": 5,
  "total": 10,
  "offline": 5,
  "timestamp": "2024-02-23T15:32:25.678Z"
}
```

### 4. Health Check
```
GET /health
```

## Quản lý Database

### Xem dữ liệu
1. Vào cPanel → phpMyAdmin
2. Chọn database
3. Click vào bảng `user_presence`
4. Tab **"Browse"** để xem dữ liệu

### Cleanup dữ liệu cũ (optional)
Chạy SQL sau để xóa dữ liệu cũ hơn 25 giây:
```sql
DELETE FROM user_presence
WHERE last_ping < UNIX_TIMESTAMP() * 1000 - 25000;
```

### Xem user online hiện tại
```sql
SELECT uid, source, status, last_ping_iso
FROM user_presence
WHERE status = 'online'
  AND last_ping > UNIX_TIMESTAMP() * 1000 - 25000
ORDER BY last_ping DESC;
```

## Cấu trúc Database

**Bảng: user_presence**

| Column | Type | Description |
|--------|------|-------------|
| uid | VARCHAR(255) | User ID (Primary Key) |
| source | VARCHAR(100) | Nguồn ping |
| status | ENUM | 'online' hoặc 'offline' |
| last_ping | BIGINT | Timestamp (milliseconds) |
| last_ping_iso | VARCHAR(50) | ISO timestamp format |
| created_at | TIMESTAMP | Thời gian tạo |
| updated_at | TIMESTAMP | Thời gian cập nhật |

**Indexes:**
- Primary key: `uid`
- Index: `idx_status`
- Index: `idx_last_ping`

## Cách hoạt động

1. **Ping (Update)**: Client ping mỗi 20 giây → Cập nhật vào database
2. **Check Status**:
   - Query database tìm user
   - Chỉ trả về "online" nếu last_ping < 25 giây
   - Ngược lại trả về "offline"
3. **Auto-cleanup**: Dữ liệu cũ tự động được filter khi query

## Xử lý sự cố

### Lỗi "Database connection failed"
- Kiểm tra lại thông tin database trong `.env`
- Đảm bảo database user có đủ privileges
- Kiểm tra DB_HOST (thường là `localhost`)

### Lỗi "Table doesn't exist"
- Chạy lại file `database.sql` trong phpMyAdmin
- Kiểm tra database name có đúng không

### Lỗi "ECONNREFUSED"
- Kiểm tra PORT có đúng không (mặc định 3000)
- Restart application trong cPanel

### API không hoạt động
- Kiểm tra Node.js version (phải >= 18.0.0)
- Xem log trong cPanel Node.js section
- Đảm bảo express và mysql2 đã được cài (`npm install`)

### Test trong SSH
```bash
# SSH vào server
cd public_html/user-presence-api
npm install
npm start
```

## Security Tips

1. **Không expose file `.env`** - đã thêm vào .gitignore
2. **Đổi password database** mạnh
3. **Giới hạn rate limiting** (optional - có thể thêm middleware)
4. **Sử dụng HTTPS** - enable SSL trong cPanel

## Backup Database

Định kỳ backup database:
1. cPanel → Backups → Download a MySQL Database Backup
2. Hoặc dùng phpMyAdmin → Export

## Performance Tips

- Table đã có indexes để tối ưu query
- Sử dụng connection pool (max 10 connections)
- Auto-cleanup dữ liệu cũ khi query
- Có thể thêm cronjob để cleanup định kỳ

## Tài liệu tham khảo

- Express.js: https://expressjs.com/
- MySQL2: https://github.com/sidorares/node-mysql2
- cPanel Node.js: https://docs.cpanel.net/cpanel/software/setup-node-js-app/
